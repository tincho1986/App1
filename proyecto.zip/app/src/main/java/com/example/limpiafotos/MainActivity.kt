package com.example.limpiafotos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : Activity() {

    data class Foto(val id: Long, val nombre: String, val ruta: String, val size: Long)

    private lateinit var etTexto: EditText
    private lateinit var etMb: EditText
    private lateinit var etFecha: EditText
    private lateinit var cbCap: CheckBox
    private lateinit var tvRes: TextView
    private lateinit var btnBorrar: Button

    private var encontradas: List<Foto> = emptyList()
    private val lotes = mutableListOf<List<Uri>>()
    private var hechas = 0
    private var loteActual = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        val titulo = TextView(this)
        titulo.text = "Limpia Fotos"
        titulo.textSize = 26f
        col.addView(titulo)

        val ayuda = TextView(this)
        ayuda.text = "Completá los filtros que quieras. Se aplican todos juntos. Lo que dejes vacío no se usa. Las fotos van a la papelera de Android (30 días), no se borran de golpe."
        ayuda.textSize = 15f
        col.addView(ayuda)

        etTexto = EditText(this)
        etTexto.hint = "Carpeta o nombre contiene (ej: WhatsApp)"
        col.addView(etTexto)

        etMb = EditText(this)
        etMb.hint = "Más pesadas que (MB)"
        etMb.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        col.addView(etMb)

        etFecha = EditText(this)
        etFecha.hint = "Anteriores a (AAAA-MM-DD)"
        col.addView(etFecha)

        cbCap = CheckBox(this)
        cbCap.text = "Solo capturas de pantalla"
        col.addView(cbCap)

        val btnBuscar = Button(this)
        btnBuscar.text = "Buscar"
        btnBuscar.setOnClickListener { buscar() }
        col.addView(btnBuscar)

        tvRes = TextView(this)
        tvRes.textSize = 16f
        tvRes.setPadding(0, pad, 0, pad)
        col.addView(tvRes)

        btnBorrar = Button(this)
        btnBorrar.text = "Mover a la papelera"
        btnBorrar.isEnabled = false
        btnBorrar.setOnClickListener { confirmar() }
        col.addView(btnBorrar)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
    }

    private fun permisoNecesario() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun tienePermiso() =
        checkSelfPermission(permisoNecesario()) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (tienePermiso()) buscar() else tvRes.text = "Sin permiso para ver las fotos no puedo buscar."
    }

    private fun buscar() {
        if (!tienePermiso()) {
            requestPermissions(arrayOf(permisoNecesario()), 1)
            return
        }
        val texto = etTexto.text.toString().trim().lowercase()
        val minBytes = (etMb.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0) * 1048576.0
        val soloCap = cbCap.isChecked
        val antes: Long? = try {
            val f = etFecha.text.toString().trim()
            if (f.isEmpty()) null else SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(f)!!.time
        } catch (e: Exception) {
            tvRes.text = "Fecha inválida. Usá el formato AAAA-MM-DD, por ejemplo 2020-12-31."
            return
        }
        if (texto.isEmpty() && minBytes == 0.0 && antes == null && !soloCap) {
            tvRes.text = "Poné al menos un filtro, si no se seleccionarían todas tus fotos."
            btnBorrar.isEnabled = false
            return
        }
        tvRes.text = "Buscando..."
        btnBorrar.isEnabled = false
        Thread {
            val lista = ArrayList<Foto>()
            val proj = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.RELATIVE_PATH,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.DATE_ADDED
            )
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val nombre = c.getString(1) ?: ""
                    val ruta = c.getString(2) ?: ""
                    val size = c.getLong(3)
                    val taken = c.getLong(4)
                    val fecha = if (taken > 0) taken else c.getLong(5) * 1000
                    val tl = (ruta + nombre).lowercase()
                    if (texto.isNotEmpty() && !tl.contains(texto)) continue
                    if (soloCap && !(tl.contains("screenshot") || tl.contains("captura"))) continue
                    if (size < minBytes) continue
                    if (antes != null && fecha >= antes) continue
                    lista.add(Foto(c.getLong(0), nombre, ruta, size))
                }
            }
            runOnUiThread {
                encontradas = lista
                if (lista.isEmpty()) {
                    tvRes.text = "No encontré fotos con esos filtros."
                } else {
                    val mb = lista.sumOf { it.size } / 1048576
                    val ej = lista.take(5).joinToString("\n") { "• " + it.ruta + it.nombre }
                    tvRes.text = "Encontré ${lista.size} fotos (${mb} MB).\n\nEjemplos:\n$ej"
                    btnBorrar.text = "Mover ${lista.size} fotos a la papelera"
                    btnBorrar.isEnabled = true
                }
            }
        }.start()
    }

    private fun confirmar() {
        AlertDialog.Builder(this)
            .setTitle("¿Mover ${encontradas.size} fotos a la papelera?")
            .setMessage("Quedan 30 días en la papelera y las podés recuperar desde la Galería. Android te va a pedir confirmación.")
            .setPositiveButton("Mover") { _, _ -> iniciar() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun iniciar() {
        val uris = encontradas.map { ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, it.id) }
        lotes.clear()
        lotes.addAll(uris.chunked(300))
        hechas = 0
        siguiente()
    }

    private fun siguiente() {
        if (lotes.isEmpty()) {
            tvRes.text = "Listo. Se movieron $hechas fotos a la papelera."
            btnBorrar.isEnabled = false
            return
        }
        val lote = lotes.removeAt(0)
        loteActual = lote.size
        val pi = MediaStore.createTrashRequest(contentResolver, lote, true)
        startIntentSenderForResult(pi.intentSender, 42, null, 0, 0, 0)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            if (resultCode == RESULT_OK) {
                hechas += loteActual
                siguiente()
            } else {
                lotes.clear()
                tvRes.text = "Cancelaste. Se movieron $hechas fotos a la papelera."
            }
        }
    }
}
