package com.example.limpiafotos

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import android.view.WindowManager
import android.widget.*
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter

class MainActivity : Activity() {

    class Foto(val id: Long, val carpeta: String, val nombre: String) {
        var color = ""
        var labels = ""
    }

    private val colores = listOf("Cualquier color", "negro", "blanco", "gris", "rojo", "naranja", "amarillo", "verde", "celeste", "azul", "violeta", "rosa")

    private val dic: Map<String, List<String>> = mapOf(
        "comida" to listOf("food", "dish", "cuisine", "meal", "drink"),
        "persona" to listOf("face", "selfie", "smile", "crowd", "hair", "people"),
        "gente" to listOf("face", "selfie", "smile", "crowd", "hair", "people"),
        "gato" to listOf("cat"),
        "perro" to listOf("dog"),
        "mascota" to listOf("pet", "cat", "dog"),
        "auto" to listOf("car", "vehicle"),
        "coche" to listOf("car", "vehicle"),
        "flor" to listOf("flower"),
        "playa" to listOf("beach", "sea"),
        "cielo" to listOf("sky"),
        "edificio" to listOf("building"),
        "texto" to listOf("text", "font", "handwriting", "paper", "document"),
        "papel" to listOf("paper", "document", "poster"),
        "bebe" to listOf("baby", "toddler"),
        "pantalla" to listOf("screen", "display", "electronic device"),
        "ropa" to listOf("clothing", "fashion", "outerwear")
    )

    private var fotos: List<Foto> = emptyList()
    private val cache = HashMap<Long, Pair<String, String>>()
    private val grupos = ArrayList<Pair<CheckBox, List<Foto>>>()
    private val lotes = mutableListOf<List<Uri>>()
    private var analizando = false
    private var parar = false
    private var gen = 0
    private var hechas = 0
    private var loteActual = 0

    private lateinit var btnAnalizar: Button
    private lateinit var tvEstado: TextView
    private lateinit var llResumen: LinearLayout
    private lateinit var etCarpeta: EditText
    private lateinit var etContenido: EditText
    private lateinit var spColor: Spinner
    private lateinit var tvRes: TextView
    private lateinit var llRes: LinearLayout
    private lateinit var btnBorrar: Button

    private val labeler by lazy {
        ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build())
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun tv(s: String, sz: Float = 15f): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = sz
        return t
    }
    private fun btn(s: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = s
        b.setOnClickListener { f() }
        return b
    }
    private fun uri(id: Long): Uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))

        col.addView(tv("Limpia Fotos", 26f))
        col.addView(tv("1) Analizá tus fotos una sola vez (tarda un rato). 2) Mirá el resumen por carpeta y por contenido. 3) Buscá, revisá las miniaturas y mové a la papelera. Nada se borra de golpe: queda 30 días en la papelera."))

        btnAnalizar = btn("Analizar mis fotos") { toggleAnalisis() }
        col.addView(btnAnalizar)
        tvEstado = tv("")
        col.addView(tvEstado)
        col.addView(btn("Ver resumen") { resumen() })
        llResumen = LinearLayout(this)
        llResumen.orientation = LinearLayout.VERTICAL
        col.addView(llResumen)

        col.addView(tv("Buscar", 20f))
        etCarpeta = EditText(this)
        etCarpeta.hint = "Carpeta contiene (ej: WhatsApp)"
        col.addView(etCarpeta)
        etContenido = EditText(this)
        etContenido.hint = "Contenido (ej: comida, gato, persona)"
        col.addView(etContenido)
        spColor = Spinner(this)
        spColor.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colores)
        col.addView(spColor)
        col.addView(btn("Buscar") { buscar() })

        tvRes = tv("")
        tvRes.setPadding(0, dp(12), 0, dp(8))
        col.addView(tvRes)
        llRes = LinearLayout(this)
        llRes.orientation = LinearLayout.VERTICAL
        col.addView(llRes)
        btnBorrar = btn("Mover a la papelera") { confirmar() }
        btnBorrar.isEnabled = false
        col.addView(btnBorrar)

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
        cargarCache()
    }

    private fun permiso() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun tienePermiso() = checkSelfPermission(permiso()) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        tvEstado.text = if (tienePermiso()) "Permiso concedido. Tocá el botón de nuevo." else "Sin permiso no puedo ver las fotos."
    }

    private fun cargarCache() {
        try {
            val f = File(filesDir, "cache.tsv")
            if (f.exists()) f.forEachLine { l ->
                val p = l.split("\t")
                val id = p[0].toLongOrNull()
                if (id != null && p.size >= 3) cache[id] = Pair(p[1], p[2])
            }
        } catch (e: Exception) {
        }
    }

    private fun leerFotos() {
        val lista = ArrayList<Foto>()
        val proj = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.RELATIVE_PATH
        )
        contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val f = Foto(c.getLong(0), c.getString(2) ?: "(sin carpeta)", c.getString(1) ?: "")
                val k = cache[f.id]
                if (k != null) {
                    f.color = k.first
                    f.labels = k.second
                }
                lista.add(f)
            }
        }
        fotos = lista
    }

    private fun toggleAnalisis() {
        if (analizando) {
            parar = true
            tvEstado.text = "Deteniendo..."
            return
        }
        if (!tienePermiso()) {
            requestPermissions(arrayOf(permiso()), 1)
            return
        }
        analizando = true
        parar = false
        btnAnalizar.text = "Detener análisis"
        tvEstado.text = "Preparando..."
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread { analizar() }.start()
    }

    private fun colorDe(b: Bitmap): String {
        val s = Bitmap.createScaledBitmap(b, 8, 8, true)
        val cnt = IntArray(colores.size)
        val hsv = FloatArray(3)
        for (x in 0 until 8) for (y in 0 until 8) {
            Color.colorToHSV(s.getPixel(x, y), hsv)
            val h = hsv[0]
            val sa = hsv[1]
            val v = hsv[2]
            val n = when {
                v < 0.2f -> "negro"
                sa < 0.15f -> if (v > 0.8f) "blanco" else "gris"
                h < 15f || h >= 345f -> "rojo"
                h < 45f -> "naranja"
                h < 70f -> "amarillo"
                h < 165f -> "verde"
                h < 200f -> "celeste"
                h < 260f -> "azul"
                h < 300f -> "violeta"
                else -> "rosa"
            }
            cnt[colores.indexOf(n)]++
        }
        var best = 1
        for (i in 1 until cnt.size) if (cnt[i] > cnt[best]) best = i
        return colores[best]
    }

    private fun analizar() {
        leerFotos()
        val pend = fotos.filter { !cache.containsKey(it.id) }
        var out: BufferedWriter? = null
        try {
            out = BufferedWriter(FileWriter(File(filesDir, "cache.tsv"), true))
            var n = 0
            for (f in pend) {
                if (parar) break
                var color = "?"
                var labs = ""
                try {
                    val bmp = contentResolver.loadThumbnail(uri(f.id), Size(224, 224), null)
                    color = colorDe(bmp)
                    labs = Tasks.await(labeler.process(InputImage.fromBitmap(bmp, 0))).joinToString("|") { it.text }
                } catch (e: Exception) {
                }
                cache[f.id] = Pair(color, labs)
                f.color = color
                f.labels = labs
                out.write("${f.id}\t$color\t$labs\n")
                n++
                if (n % 20 == 0) {
                    out.flush()
                    val hechasAhora = n
                    runOnUiThread { tvEstado.text = "Analizadas $hechasAhora de ${pend.size} pendientes. Dejá la app abierta y el cargador conectado." }
                }
            }
        } catch (e: Exception) {
        } finally {
            try { out?.close() } catch (e: Exception) { }
        }
        runOnUiThread {
            analizando = false
            btnAnalizar.text = "Analizar mis fotos"
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            tvEstado.text = "Análisis listo: ${fotos.count { cache.containsKey(it.id) }} de ${fotos.size} fotos analizadas."
            resumen()
        }
    }

    private fun resumen() {
        llResumen.removeAllViews()
        if (!tienePermiso()) {
            llResumen.addView(tv("Primero tocá Analizar para dar permiso."))
            return
        }
        if (fotos.isEmpty()) leerFotos()
        val link = Color.parseColor("#1A5FB4")
        llResumen.addView(tv("Carpetas (tocá una para usarla)", 18f))
        fotos.groupBy { it.carpeta }.entries.sortedByDescending { it.value.size }.take(15).forEach { e ->
            val t = tv("• ${e.key} (${e.value.size})")
            t.setTextColor(link)
            t.setPadding(0, dp(6), 0, dp(6))
            t.setOnClickListener { etCarpeta.setText(e.key) }
            llResumen.addView(t)
        }
        val an = fotos.filter { cache.containsKey(it.id) }
        if (an.isEmpty()) return
        llResumen.addView(tv("Contenido detectado (tocá uno)", 18f))
        val cont = HashMap<String, Int>()
        an.forEach { f -> f.labels.split("|").filter { it.isNotEmpty() }.forEach { cont[it] = (cont[it] ?: 0) + 1 } }
        cont.entries.sortedByDescending { it.value }.take(25).forEach { e ->
            val t = tv("• ${e.key} (${e.value})")
            t.setTextColor(link)
            t.setPadding(0, dp(6), 0, dp(6))
            t.setOnClickListener { etContenido.setText(e.key) }
            llResumen.addView(t)
        }
        val cc = an.groupBy { it.color }.filter { it.key != "?" && it.key.isNotEmpty() }.entries.sortedByDescending { it.value.size }
        llResumen.addView(tv("Colores predominantes: " + cc.joinToString(", ") { "${it.key} (${it.value.size})" }))
    }

    private fun buscar() {
        if (!tienePermiso()) {
            requestPermissions(arrayOf(permiso()), 1)
            return
        }
        val carp = etCarpeta.text.toString().trim().lowercase()
        val cont = etContenido.text.toString().trim().lowercase()
        val colSel = spColor.selectedItem as String
        val conColor = colSel != colores[0]
        if (carp.isEmpty() && cont.isEmpty() && !conColor) {
            tvRes.text = "Poné al menos un filtro."
            return
        }
        if (fotos.isEmpty()) leerFotos()
        val terminos: List<String> = if (cont.isEmpty()) emptyList() else (dic[cont] ?: listOf(cont))
        val ok = fotos.filter { f ->
            (carp.isEmpty() || (f.carpeta + f.nombre).lowercase().contains(carp)) &&
                (terminos.isEmpty() || (f.labels.isNotEmpty() && terminos.any { t -> f.labels.lowercase().contains(t) })) &&
                (!conColor || f.color == colSel)
        }
        mostrar(ok, cont.isNotEmpty() || conColor)
    }

    private fun mostrar(ok: List<Foto>, usaAnalisis: Boolean) {
        llRes.removeAllViews()
        grupos.clear()
        gen++
        val miGen = gen
        val porCarpeta = ok.groupBy { it.carpeta }.entries.sortedByDescending { it.value.size }
        var msg = "Encontré ${ok.size} fotos en ${porCarpeta.size} carpetas. Revisá las miniaturas y dejá tildadas solo las carpetas que querés mover."
        if (usaAnalisis) msg += " (Solo cuenta fotos ya analizadas: ${fotos.count { cache.containsKey(it.id) }} de ${fotos.size}.)"
        if (porCarpeta.size > 40) msg += " Muestro las 40 carpetas con más fotos."
        tvRes.text = msg
        val thumbs = ArrayList<Pair<ImageView, Long>>()
        porCarpeta.take(40).forEach { e ->
            val cb = CheckBox(this)
            cb.text = "${e.key}\n${e.value.size} fotos"
            cb.isChecked = true
            cb.setOnCheckedChangeListener { _, _ -> actualizarBoton() }
            llRes.addView(cb)
            val fila = LinearLayout(this)
            fila.orientation = LinearLayout.HORIZONTAL
            e.value.take(4).forEach { f ->
                val iv = ImageView(this)
                val lp = LinearLayout.LayoutParams(dp(72), dp(72))
                lp.setMargins(0, 0, dp(6), dp(10))
                iv.layoutParams = lp
                iv.scaleType = ImageView.ScaleType.CENTER_CROP
                fila.addView(iv)
                thumbs.add(Pair(iv, f.id))
            }
            llRes.addView(fila)
            grupos.add(Pair(cb, e.value))
        }
        actualizarBoton()
        Thread {
            for ((iv, id) in thumbs) {
                if (gen != miGen) return@Thread
                try {
                    val bmp = contentResolver.loadThumbnail(uri(id), Size(160, 160), null)
                    runOnUiThread { iv.setImageBitmap(bmp) }
                } catch (e: Exception) {
                }
            }
        }.start()
    }

    private fun seleccionadas(): List<Foto> = grupos.filter { it.first.isChecked }.flatMap { it.second }

    private fun actualizarBoton() {
        val n = seleccionadas().size
        btnBorrar.isEnabled = n > 0
        btnBorrar.text = "Mover $n fotos a la papelera"
    }

    private fun confirmar() {
        val n = seleccionadas().size
        AlertDialog.Builder(this)
            .setTitle("¿Mover $n fotos a la papelera?")
            .setMessage("Quedan 30 días en la papelera y las podés recuperar desde la Galería. Android te va a pedir confirmación.")
            .setPositiveButton("Mover") { _, _ -> iniciar() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun iniciar() {
        lotes.clear()
        lotes.addAll(seleccionadas().map { uri(it.id) }.chunked(300))
        hechas = 0
        siguiente()
    }

    private fun siguiente() {
        if (lotes.isEmpty()) {
            tvRes.text = "Listo. Se movieron $hechas fotos a la papelera."
            llRes.removeAllViews()
            grupos.clear()
            btnBorrar.isEnabled = false
            leerFotos()
            resumen()
            return
        }
        val lote = lotes.removeAt(0)
        loteActual = lote.size
        val pi = MediaStore.createTrashRequest(contentResolver, lote, true)
        startIntentSenderForResult(pi.intentSender, 42, null, 0, 0, 0)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42) {
            if (resultCode == RESULT_OK) {
                hechas += loteActual
                siguiente()
            } else {
                lotes.clear()
                tvRes.text = "Cancelaste. Se movieron $hechas fotos a la papelera."
                leerFotos()
            }
        }
    }
}
